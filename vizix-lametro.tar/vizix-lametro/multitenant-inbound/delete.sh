docker service rm vizix_haproxy
docker config rm vizix_haproxy
docker config rm vizix_cert
